import React from 'react';
import { Line } from 'react-chartjs-2';

const DarkAreaChart = ({ data }) => {
  const options = {
    maintainAspectRatio: false,
    legend: {
      display: false
    },
    scales: {
      xAxes: [{
        type: 'time',
        time: {
          unit: 'day'
        },
        ticks: {
          fontColor: 'white' // X-axis labels color
        },
        gridLines: {
          color: 'rgba(255,255,255,0.1)' // X-axis gridlines color
        }
      }],
      yAxes: [{
        ticks: {
          fontColor: 'white', // Y-axis labels color
          beginAtZero: true
        },
        gridLines: {
          color: 'rgba(255,255,255,0.1)' // Y-axis gridlines color
        }
      }]
    }
  };

  return (
    <div>
      <Line data={data} options={options} />
    </div>
  );
};

export default DarkAreaChart;
