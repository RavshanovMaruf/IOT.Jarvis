// import './App.css';
// import React, { useState, useEffect } from 'react';
// import { Line } from 'react-chartjs-2';
// import 'chart.js/auto';
// import axios from 'axios';
// import WaterBottle from './WaterBottle';
// import WaterWaveAnimation from './WaterWaveAnimation';

// const App = () => {
//   const [dataPoints, setDataPoints] = useState([]);
//   const [temperature, setTemperature] = useState([]);
//   const [humidity, setHumidity] = useState([]);
//   const [danger, setCondition] = useState(null);
//   const [waterLevelCondition, setWaterLevel] = useState([]);
//   const [waterLevel, setWaterLevelNumber] = useState([]);

//   useEffect(() => {
//     fetchDataAll();
//     fetchDataSingle();

//     // Set interval to fetch data every 5 seconds
//     const interval = setInterval(() => {
//       fetchDataAll();
//       fetchDataSingle();
//     }, 100);

//     // Clear interval when component unmounts
//     return () => clearInterval(interval);
//   }, []);

//   const fetchDataAll = async () => {
//     try {
//       const response = await axios.get('https://localhost:7293/humidity-all-info');
//       setDataPoints(response.data);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     }
//   };

//   const fetchDataSingle = async () => {
//     try {
//       const response = await axios.get('https://localhost:7293/humidity');
//       const { humidity, temperature, danger, waterLevelCondition, waterLevel } = response.data;
//       setHumidity(humidity);
//       setTemperature(temperature);
//       setCondition(danger);
//       setWaterLevel(waterLevelCondition);
//       setWaterLevelNumber(waterLevel);
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     }
//   };  
   

//   const humidityData = {
//     labels: dataPoints.map(dataPoint => new Date(dataPoint.time).toLocaleTimeString()),
//     datasets: [
//       {
//         label: 'Humidity',
//         fill: true,
//         backgroundColor: 'rgba(75, 192, 192, 0.2)',
//         borderColor: 'rgba(75, 192, 192, 1)',
//         data: dataPoints.map(dataPoint => dataPoint.humidity)
//       }
//     ]
//   };

//   const temperatureData = {
//     labels: dataPoints.map(dataPoint => new Date(dataPoint.time).toLocaleTimeString()),
//     datasets: [
//       {
//         label: 'Temperature',
//         fill: true,
//         backgroundColor: 'rgba(255, 99, 132, 0.2)',
//         borderColor: 'rgba(255, 99, 132, 1)',
//         data: dataPoints.map(dataPoint => dataPoint.temperature)
//       }
//     ]
//   };
  

//   return (
//     <div className="App">
//       <header className="App-header">
//       {/* <p>
//         Welcome to our iot project.
//       </p> */}
//       <div className="info-container">
//       <p>
//         Temperature: {temperature} °C
//       </p>
//       <p>
//         Humidity: {humidity}%
//       </p>
//     </div>
//     <div className="water-container">
//       <p>
//         Water Level: {waterLevelCondition}
//       </p>
//     </div>
//     <div className="health">
//       <p>
//         Health: {danger ? <span className="popup red">Unhealthy</span> : <span className="green">Healthy</span>}
//       </p>
//     </div>
//         <div className="chart-container">
//           <div className="chart">
//             <h2>Temperature</h2>
//             <Line data={temperatureData} />
//           </div>
//           <div className="water-container">
//           <h2>Water Level</h2>
//           {/* <WaterWaveAnimation waterLevel={waterLevel}/> */}
//           <WaterBottle waterLevel={waterLevel}/>
//           </div>
//           <div className="chart">
//             <h2>Humidity</h2>
//             <Line data={humidityData} />
//           </div>
//         </div>
//       </header>
//     </div>
//   );
// }

// export default App;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const FileReadComponent = () => {
//   const [waterLevel, setWaterLevel] = useState('');
//   const [temperature, setTemperature] = useState('');
//   const [humidity, setHumidity] = useState('');

//   useEffect(() => {
//     fetchFileContent();
//   }, []);

//   const fetchFileContent = async () => {
//     try {
//       const response = await axios.get('http://localhost:3001/file');
//       setWaterLevel(response.data.waterLevel);
//       setTemperature(response.data.temperature);
//       setHumidity(response.data.humidity);
//     } catch (error) {
//       console.error('Failed to fetch file content:', error);
//     }
//   };

//   return (
//     <div>
//       <div>
//         <h2>File Content:</h2>
//         <pre>{waterLevel}</pre>
//         <p>{temperature}</p>
//         <p>{humidity}</p>
//       </div>
//     </div>
//   );
// };

// export default FileReadComponent;

import './App.css';
import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';
import axios from 'axios';
import WaterBottle from './WaterBottle';
import WaterWaveAnimation from './WaterWaveAnimation';

const App = () => {
  const [dataPoints, setDataPoints] = useState([]);
  const [temperature, setTemperature] = useState([]);
  const [humidity, setHumidity] = useState([]);
  const [danger, setCondition] = useState(null);
  const [waterLevelCondition, setWaterLevel] = useState([]);
  const [waterLevel, setWaterLevelNumber] = useState([]);

  useEffect(() => {
    fetchDataAll();
    fetchDataSingle();

    // Set interval to fetch data every 5 seconds
    const interval = setInterval(() => {
      fetchDataAll();
      fetchDataSingle();
    }, 1000);

    // Clear interval when component unmounts
    return () => clearInterval(interval);
  }, []);

  const fetchDataAll = async () => {
    try {
      const response = await axios.get('http://localhost:3001/data');
      setDataPoints(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const fetchDataSingle = async () => {
    try {
      const response = await axios.get('http://localhost:3001/file');
      const { humidity, temperature, waterLevel, danger } = response.data;
      setHumidity(humidity);
      setTemperature(temperature);
      setWaterLevelNumber(waterLevel);
      setCondition(danger);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };  
   

  const humidityData = {
    labels: ['40 sec', '30 sec', '20 sec', '10 sec', 'now'],
    datasets: [
      {
        label: 'Humidity',
        fill: true,
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        data: dataPoints.map(dataPoint => dataPoint.humidity)
      }
    ]
  };

  const temperatureData = {
    labels: ['40 sec', '30 sec', '20 sec', '10 sec', 'now'],
    datasets: [
      {
        label: 'Temperature',
        fill: true,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        data: dataPoints.map(dataPoint => dataPoint.temperature)
      }
    ]
  };
  

  return (
    <div className="App">
      <header className="App-header">
      {/* <p>
        Welcome to our iot project.
      </p> */}
      <div className="info-container">
      <p>
        Temperature: {temperature} °C
      </p>
      <p>
        Humidity: {humidity}%
      </p>
    </div>
    <div className="water-container">
      <p>
        Water Level: {waterLevel}
      </p>
    </div>
    <div className="health">
      <p>
        Health: {danger ? <span className="popup red">Unhealthy</span> : <span className="green">Healthy</span>}
      </p>
    </div>
        <div className="chart-container">
          <div className="chart">
            <h2>Temperature</h2>
            <Line data={temperatureData} />
          </div>
          <div className="water-container">
          <h2>Water Level</h2>
          {/* <WaterWaveAnimation waterLevel={waterLevel}/> */}
          <WaterBottle waterLevel={waterLevel}/>
          </div>
          <div className="chart">
            <h2>Humidity</h2>
            <Line data={humidityData} />
          </div>
        </div>
      </header>
    </div>
  );
}

export default App;