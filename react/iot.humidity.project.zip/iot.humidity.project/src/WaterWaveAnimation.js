// import React from 'react';
// import './WaterWaveAnimation.css'; // Import your CSS file containing styles

// const WaterWaveAnimation = () => {
//   return (
//     <section>
//       <div className="waterContainer"></div>
//     </section>
//   );
// };

// export default WaterWaveAnimation;
import React from 'react';
import './WaterWaveAnimation.css'; // Import your CSS file containing styles

const WaterWaveAnimation = ({ waterLevel }) => {

  const waterStyle = {
    height: `${waterLevel}%`
  };

  return (
    <section>
      <div className="waterContainer"><div className="water-inner" style={{ height: waterLevel}}>
        </div></div>
    </section>
  );
};

export default WaterWaveAnimation;
