// import React from 'react';
// import './WaterBottle.css'; // Styles for the WaterBottle component

// const WaterBottle = ({ waterLevel }) => {
//     const calculateWaterHeight = () => {
//         const percentage = Math.max(Math.min(waterLevel, 100), 0); // Ensure the percentage is within 0-100 range
//         return `${percentage}%`; // Return the percentage as a string for CSS height
//       };

//   return (
//     <div className={`water-bottle`}>
//       <div className="bottle">
//         <div className="water" style={{ height: calculateWaterHeight()}}></div>
//       </div>
//     </div>
//   );
// };

// export default WaterBottle;
import React from 'react';
import './WaterBottle.css'; // Styles for the WaterBottle component

const WaterBottle = ({ waterLevel }) => {
    const calculateWaterHeight = () => {
        // Scale the water level to fit within the 0-100 range
        const percentage = Math.max(Math.min((waterLevel / 100) * 100, 100), 0); // Ensure the percentage is within 0-100 range
        return `${percentage}%`; // Return the percentage as a string for CSS height
    };

    return (
        <div className={`water-bottle`}>
            <div className="bottle">
                <div className="water" style={{ height: calculateWaterHeight()}}></div>
            </div>
        </div>
    );
};

export default WaterBottle;
