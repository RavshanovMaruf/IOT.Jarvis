﻿namespace humidity.api.Entity.framework
{
    public enum WaterLevel
    {
        Full = 0,
        Medium = 1,
        Low = 2,
        None = 3
    }
}
